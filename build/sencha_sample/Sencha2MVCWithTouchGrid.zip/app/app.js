
Ext.Loader.setConfig({
	enabled : true,
	paths : {
		'Ext.ux.touch.grid' : './Ext.ux.touch.grid'
	}
});

Ext.require([ 'Ext.ux.touch.grid.View', 
              'Ext.ux.touch.grid.feature.Feature',
              'Ext.ux.touch.grid.feature.Sorter']);


Ext.application({
	
    name: 'AppMVC',

    stores: ['Productions'],  
    views : ["MainView","GoalView"],
	controllers: ['Main'], 
	
	initialize: function () {
		console.log('app initialize');

	},

	launch: function() {
		
        //alert("all Set");
		Ext.create("AppMVC.view.MainView");

	},

});


