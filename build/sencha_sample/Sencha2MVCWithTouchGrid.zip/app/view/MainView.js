

var filterBtn = Ext.create('Ext.Button', {
	ui : 'decline',
	id : "filterBtn",
	text: "19810306",// app.js global var
	handler : function(btn) {

	}
});


var chartBtn = Ext.create('Ext.Button', {
	width : 70,
	ui : 'confirm',
	id : "chartBtn",
	text: 'Chart',
	handler : function(btn) {

	}
});




Ext.define("AppMVC.view.MainView", {
	extend: "Ext.TabPanel",
    xtype: "mainview",
    id : "MainView",
	config: {
		fullscreen: true,

		items: [

				{
					xtype: "GoalView",
					title: "Goal",

				}


				]
	},

		initialize: function () {

		this._tabBar.add(chartBtn);
		this._tabBar.add(filterBtn);
		
		console.log('initialize MainView ');

        this.fireEvent('MainViewLaunch');
		this.callParent();
	}

});
