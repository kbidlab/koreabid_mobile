

Ext.define("AppMVC.view.GoalView", {
	extend: 'Ext.carousel.Carousel',
	xtype: 'GoalView',
    
	defaults: {
		scroll: 'vertical'
	},
	layout: 'fit',
	config: {
        id : 'GoalView',
		items: [
						 {
							 title: 'MonthlyGoal',
                             id : 'MonthlyGoal',
							 xtype: 'touchgridpanel',
                             
							 //store: Ext.getStore("MonthlyGoals"),
							 layout: 'fit',
/*							 features: [{
								 ftype: 'Ext.ux.touch.grid.feature.Sorter',
								 launchFn: 'initialize'
							 }],*/

							 columns: [
								{
									header: 'MONTHLY',
									dataIndex: 'PROFITGROUP',
									style: 'padding-left: 1em;',
									//flex:10,
									width: '20%',
									filter: {
										type: 'string'
									}
								},
								{
									header: 'PROFITCNT',
									dataIndex: 'PROFITCENTER',
									style: 'padding-left: 1em;',
									//flex:2,
									width: '20%',
									filter: {
										type: 'string'
									}
								},
								{
									header: 'QTY(Ku)',
									dataIndex: 'GOALQTY',
									cls: 'centered-cell',
									//flex:2,
									width: '20%',
									renderer: function (value, values) {
										var color = (value > 0) ? '009933'
												: 'FF0000';
										return '<span style="color: #' + color
										+ ';">' + value + '</span>';
									}
								},
								{
									header: 'AMT(K$)',
									dataIndex: 'GOALAMT',
									cls: 'centered-cell',
									//flex:2,
									width: '20%',
									renderer: function (value, values) {
										var color = (value > 0) ? '009933'
												: 'FF0000';
										return '<span style="color: #' + color
										+ ';">' + value + '</span>';
									}
								},
								{
									header: 'OPS(K$)',
									dataIndex: 'GOALOPSAMT',
									cls: 'centered-cell',
									//flex:2,
									width: '20%',
									renderer: function (value, values) {
										var color = (value > 0) ? '009933'
												: 'FF0000';
										return '<span style="color: #' + color
										+ ';">' + value + '</span>';
									}
								},

								]
						 },

				 {
					 title: 'DailyGoal',
                     id: 'DailyGoal',
					 xtype: 'touchgridpanel',
                     //store: Ext.getStore("DailyGoals"),
					 layout: 'fit',
/*					 features: [{
						 ftype: 'Ext.ux.touch.grid.feature.Sorter',
						 launchFn: 'initialize'
					 }],*/

					 columns: [
								{
									header: 'DAILY',
									dataIndex: 'PROFITGROUP',
									style: 'padding-left: 1em;',
									//flex:10,
									width: '20%',
									filter: {
										type: 'string'
									}
								},
								{
									header: 'PROFITCNT',
									dataIndex: 'PROFITCENTER',
									style: 'padding-left: 1em;',
									//flex:2,
									width: '20%',
									filter: {
										type: 'string'
									}
								},
								{
									header: 'QTY(Ku)',
									dataIndex: 'GOALQTY',
									cls: 'centered-cell',
									//flex:2,
									width: '20%',
									renderer: function (value, values) {
										var color = (value > 0) ? '009933'
												: 'FF0000';
										return '<span style="color: #' + color
										+ ';">' + value + '</span>';
									}
								},
								{
									header: 'AMT(K$)',
									dataIndex: 'GOALAMT',
									cls: 'centered-cell',
									//flex:2,
									width: '20%',
									renderer: function (value, values) {
										var color = (value > 0) ? '009933'
												: 'FF0000';
										return '<span style="color: #' + color
										+ ';">' + value + '</span>';
									}
								},
								{
									header: 'OPS(K$)',
									dataIndex: 'GOALOPSAMT',
									cls: 'centered-cell',
									//flex:2,
									width: '20%',
									renderer: function (value, values) {
										var color = (value > 0) ? '009933'
												: 'FF0000';
										return '<span style="color: #' + color
										+ ';">' + value + '</span>';
									}
								},

								]

				 },


				 ]
	},
initialize: function () {

        console.log('initialize GoalView ');

        var MonthlyGoals = Ext.create('Ext.data.Store', {
        model: 'AppMVC.model.Production',
        data : [
                {
                ACTUALAMT: 0,
                ACTUALOPSAMT: 0,
                ACTUALQTY: 0,
                DELTAINPUTAMT: 0,
                DELTAOUTPUTAMT: -12125,
                GOALAMT: 12125,
                GOALOPSAMT: 25014,
                GOALQTY: 80290,
                PROFITCENTER: "WIRELESS",
                PROFITGROUP: "LLP",
                REPORTTYPE: "MonthlyGoal",
                }
                ]
        });

        var DailyGoals = Ext.create('Ext.data.Store', {
        model: 'AppMVC.model.Production',
        data : [
                                {
                ACTUALAMT: 0,
                ACTUALOPSAMT: 0,
                ACTUALQTY: 0,
                DELTAINPUTAMT: 0,
                DELTAOUTPUTAMT: -12125,
                GOALAMT: 12125,
                GOALOPSAMT: 25014,
                GOALQTY: 80290,
                PROFITCENTER: "WIRELE",
                PROFITGROUP: "APS",
                REPORTTYPE: "DailyGoal",
                }]

        });

        var TmpTouchGrid1 = this.getInnerItemAt(0);
        TmpTouchGrid1.setStore(MonthlyGoals);

        var TmpTouchGrid2 = this.getInnerItemAt(1);
        TmpTouchGrid2.setStore(DailyGoals);

	    this.fireEvent('GoalViewLaunch');
		this.callParent();
	}
});

