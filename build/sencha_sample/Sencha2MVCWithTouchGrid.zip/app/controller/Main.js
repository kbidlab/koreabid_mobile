

Ext.define('AppMVC.controller.Main', {

    extend: 'Ext.app.Controller',

    // These "refs" will generate "getters" for each of the view component instances
    config: {
        refs: {

            //main view com refs
            FilterBtn: '#filterBtn',
            ChartBtn: '#chartBtn',

            //view Refs
            MainView: '#MainView',
            GoalView: '#GoalView'

        }
    },
    init: function () {
        console.log('Init Goal controller');
        // Start listening for events on views

        this.control({

            '#MainView': {
                MainViewLaunch: 'CompletedMainView',
                activeitemchange: 'OnViewChange',
                show: 'ShowMainView'
            },
            // Example of listening by an explicit id		        
            '#chartBtn': {
                tap: 'ChangeView'
            },
            '#filterBtn': {
                tap: 'ShowDatePicker'
            }
        });
    },

    ChangeView: function () {

        console.log('chartBtn clicked');

    },

    ShowDatePicker: function () {

    	Ext.Msg.alert('not implemented yet');
    },


    CompletedMainView: function () {


    },
    
    OnViewChange: function (Container, ActiveView , lastView, eOpts) {
    	
        console.log('OnViewChanged');
    },

    ShowMainView: function () {

        console.log('Showed Main View');
        //call local function
        this.localfunction();
    },
    
    localfunction: function () {

        console.log('called localfunction');
    },


});