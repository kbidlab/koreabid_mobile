
Ext.define('AppMVC.model.Production', {
	extend : 'Ext.data.Model',
	config : {
		fields : [

		{
			name : "REPORTTYPE",
			type : "string"
		}, {
			name : "PROFITGROUP",
			type : "string"
		}, {
			name : "PROFITCENTER",
			type : "string"
		}, {
			name : "GOALQTY",
			type : "int"
		}, {
			name : "GOALAMT",
			type : "int"
		}, {
			name : "ACTUALQTY",
			type : "int"
		}, {
			name : "ACTUALAMT",
			type : "int"
		}, {
			name : "GOALOPSAMT",
			type : "int"
		}, //mapping: "description.texts.en"  
		{
			name : "ACTUALOPSAMT",
			type : "int"
/*							        	,convert: function(v, record) {
		 return parseInt(record.data.funded_amount / record.data.loan_amount * 100, 10);
		 }, */
		}, {
			name : "DELTAOUTPUTAMT",
			type : "int"
		},  {
			name : "DELTAINPUTAMT",
			type : "int"
		}, //mapping: "description.texts.en"   

		]
	},

});
