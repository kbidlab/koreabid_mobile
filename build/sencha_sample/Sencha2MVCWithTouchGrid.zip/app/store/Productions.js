Ext.define('AppMVC.store.Productions', {
	extend : 'Ext.data.Store',
    requires: 'AppMVC.model.Production',
    model: 'AppMVC.model.Production',
    data : [],
    autoLoad: true,

});
